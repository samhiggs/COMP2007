#! /usr/bin/env bash

# C/C++
# ./a1

# Java
# java A1

# Python
python3 a1.py

